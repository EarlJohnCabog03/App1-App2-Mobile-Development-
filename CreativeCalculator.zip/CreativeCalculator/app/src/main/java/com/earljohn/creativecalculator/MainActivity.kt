package com.earljohn.creativecalculator

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val seasonGroup = findViewById<RadioGroup>(R.id.seasonGroup)
        val calculateBtn = findViewById<Button>(R.id.calculateButton)

        calculateBtn.setOnClickListener {
            val selectedId = seasonGroup.checkedRadioButtonId
            if (selectedId == -1) {
                Toast.makeText(this, "Please choose a season", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val selectedText = findViewById<RadioButton>(selectedId).text.toString()

            val result = when (selectedText) {
                "Spring" -> "You are energetic and blooming 🌸"
                "Summer" -> "You shine bright like the sun ☀️"
                "Fall" -> "You're deep and thoughtful 🍂"
                "Winter" -> "Cool, calm, and collected ❄️"
                else -> "Hmm... interesting mood!"
            }

            MoodResultDialog.newInstance(result)
                .show(supportFragmentManager, "MoodDialog")
        }
    }
}
