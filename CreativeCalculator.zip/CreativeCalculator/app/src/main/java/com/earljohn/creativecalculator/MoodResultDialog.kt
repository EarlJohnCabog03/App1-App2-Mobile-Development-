package com.earljohn.creativecalculator

import android.app.Dialog
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.DialogFragment

class MoodResultDialog : DialogFragment() {

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val view = LayoutInflater.from(context).inflate(R.layout.dialog_result, null)
        val resultText = arguments?.getString("MOOD_RESULT") ?: "No result available"
        view.findViewById<TextView>(R.id.resultText).text = resultText

        return AlertDialog.Builder(requireContext())
            .setView(view)
            .setPositiveButton("OK") { _, _ -> dismiss() }
            .create()
    }

    companion object {
        fun newInstance(result: String): MoodResultDialog {
            val dialog = MoodResultDialog()
            val args = Bundle()
            args.putString("MOOD_RESULT", result)
            dialog.arguments = args
            return dialog
        }
    }
}
